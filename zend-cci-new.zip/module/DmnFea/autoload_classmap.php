<?php
return array(
	'DmnFea\Module' => __DIR__ . '/Module.php' 
);
