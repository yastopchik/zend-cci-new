<?php
return array(
	'DmnExecutor\Module' => __DIR__ . '/Module.php' 
);
