<?php
return array(
	'DmnMail\Module' => __DIR__ . '/Module.php' 
);
