<?php
return array(
	'DmnLog\Module' => __DIR__ . '/Module.php' 
);
