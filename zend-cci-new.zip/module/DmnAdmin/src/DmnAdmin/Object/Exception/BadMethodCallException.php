<?php

namespace DmnAdmin\Object\Exception;

/**
 * Bad method call exception
 */
class BadMethodCallException extends \BadMethodCallException
{
}
