<?php

namespace DmnAdmin\Object\Exception;


/**
 * Exception for DmnAdmin\Object component.
 */
class RuntimeException  extends \RuntimeException implements   ExceptionInterface
{
}
