<?php

namespace DmnAdmin\Object\Exception;


/**
 * Base exception interface for DmnAdmin\Object
 */
interface ExceptionInterface 
{
}
