<?php
return array(
	'DmnAdmin\Module' => __DIR__ . '/Module.php' 
);
