<?php
return array(
	'DmnDatabase\Module' => __DIR__ . '/Module.php' 
);
