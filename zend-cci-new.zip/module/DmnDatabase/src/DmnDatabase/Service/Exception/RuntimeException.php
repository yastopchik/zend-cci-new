<?php

namespace DmnDatabase\Service\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface {

}

?>