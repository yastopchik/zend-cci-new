<?php

namespace Solo\Stdlib\Exception;

/**
 * 
 * @subpackage Exception
 *            
 */
final class NotSupportedException extends \LogicException implements ExceptionInterface {

}

?>