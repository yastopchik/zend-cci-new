<?php

namespace DmnDatabase\Service\Exception;

final class NotImplementedException extends \LogicException implements ExceptionInterface {

}

?>