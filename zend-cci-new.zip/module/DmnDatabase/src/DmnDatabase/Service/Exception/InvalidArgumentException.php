<?php

namespace DmnDatabase\Service\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface {

}

?>