<?php

namespace DmnDatabase\Service\Exception;

/**
 * Exception marker interface
 */
interface ExceptionInterface {
}

?>