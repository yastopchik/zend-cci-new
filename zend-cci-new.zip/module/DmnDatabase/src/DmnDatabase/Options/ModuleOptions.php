<?php

namespace DmnDatabase\Options;

use ZfcUser\Options\ModuleOptions as BaseModuleOptions;
use ZfcUser\Options\UserServiceOptionsInterface;

class ModuleOptions extends BaseModuleOptions implements UserServiceOptionsInterface{        
    
}
