<?php
return array(
  'doctrine' => array(
    'connection' => array(
      'orm_default' => array(
        'driverClass' =>'Doctrine\DBAL\Driver\PDOMySql\Driver',
        'params' => array(
          'host'     => 'localhost',
          'port'     => '3306',
          'charset'  => 'utf8',
          'collate'  => 'utf8_general_ci',
          'driverOptions' => array(
                        1002=>'SET NAMES utf8'),
          'user'     => 'ccimogil_evtpp',
          'password' => 'c2c4i7m6o0g7il',
          'dbname'   => 'ccimogil_evbeltpp',
)))));

